"""Static safety checks; they do not require a live PostgreSQL server."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'app' / '__init__.py').read_text(encoding='utf-8')
DETAIL = (ROOT / 'app' / 'templates' / 'project_detail.html').read_text(encoding='utf-8')
SCHEMA = (ROOT / 'schema.sql').read_text(encoding='utf-8')

class Day20Checks(unittest.TestCase):
    def test_routes_exist(self):
        for route in ("/entregar'", "/aprovar'", "/avaliar'"):
            self.assertIn(route, APP)
    def test_permissions_and_csrf(self):
        for name, decorator in (('submit_delivery','@student_required'), ('approve_delivery','@company_required'), ('review_project','@login_required')):
            self.assertIn(f'{decorator}\n    def {name}',APP)
            self.assertIn('valid_csrf()',APP[APP.index(f'def {name}'):APP.index(f'def {name}')+180])
    def test_transaction_and_statuses(self):
        self.assertIn("status='delivered'", APP)
        self.assertIn("status='completed'", APP)
        self.assertIn('FOR UPDATE', APP)
    def test_existing_tables(self):
        for t in ('deliveries','reviews','simulated_payments'):
            self.assertIn(f'CREATE TABLE IF NOT EXISTS {t}', SCHEMA)
    def test_simulation_explicit(self):
        self.assertIn('nenhuma cobrança, transferência ou recebimento real',APP)
        self.assertIn('PAGAMENTO SIMULADO',DETAIL)
    def test_url_validation(self):
        self.assertIn("parsed.scheme not in ('https', 'http')", APP)
    def test_review_once(self):
        self.assertIn('UNIQUE(project_id,reviewer_id)',SCHEMA)
        self.assertIn("if exists:",APP[APP.index('def review_project'):])

if __name__=='__main__':
 unittest.main()
