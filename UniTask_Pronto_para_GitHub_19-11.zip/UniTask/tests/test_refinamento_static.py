import unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]
class RefinamentoTests(unittest.TestCase):
 def test_redirecionamento(self):
  s=(P/'app/__init__.py').read_text()
  self.assertIn("flash('Bem-vindo ao UniTask!', 'success')\n                return redirect(url_for('home'))",s)
  self.assertIn("flash('Conta criada! Bem-vindo ao UniTask.",s)
 def test_profile_separated(self):
  s=(P/'app/__init__.py').read_text()
  self.assertIn("@app.get('/perfil')",s)
  self.assertIn("@app.route('/perfil/editar'",s)
  self.assertIn("SELECT COUNT(*) AS total, COALESCE(SUM(rating), 0)",s)
 def test_logo_and_footer(self):
  s=(P/'app/templates/base.html').read_text()
  self.assertIn('unitask-icon.png',s)
  self.assertIn('filename=\'favicon.png\'',s)
  self.assertIn('Entre em contato',s)
  self.assertIn('>Entrar</a>',s)
 def test_delivery_cta(self):
  self.assertIn('#entrega',(P/'app/templates/my_applications.html').read_text())
  self.assertIn('Enviar trabalho final',(P/'app/templates/project_detail.html').read_text())
 def test_no_migrations(self):
  self.assertIn('CREATE TABLE IF NOT EXISTS reviews',(P/'schema.sql').read_text())
if __name__=='__main__':unittest.main()
