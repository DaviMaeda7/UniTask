"""Checks runnable without a PostgreSQL instance; integration must be validated locally."""
from pathlib import Path
import ast
import unittest
from jinja2 import Environment, FileSystemLoader

ROOT = Path(__file__).resolve().parents[1]

class ProjectsStaticTests(unittest.TestCase):
    def test_python_compiles(self):
        ast.parse((ROOT/'app/__init__.py').read_text(encoding='utf-8'))
    def test_templates_parse(self):
        templates = ROOT/'app/templates'
        env = Environment(loader=FileSystemLoader(str(templates)))
        for file in templates.glob('*.html'):
            with self.subTest(template=file.name):
                env.parse(file.read_text(encoding='utf-8'))
    def test_routes(self):
        code=(ROOT/'app/__init__.py').read_text(encoding='utf-8')
        for route in ('/projetos/novo', '/projetos/<int:project_id>', '/meus-projetos'):
            self.assertIn(route, code)
    def test_access_and_csrf(self):
        code=(ROOT/'app/__init__.py').read_text(encoding='utf-8')
        self.assertIn('@company_required\n    def create_project()',code)
        self.assertIn('valid_csrf()\n            values =',code)
        self.assertIn('WHERE company_id=%s',code)
    def test_no_schema_change(self):
        schema=(ROOT/'schema.sql').read_text(encoding='utf-8')
        self.assertIn('CREATE TABLE IF NOT EXISTS projects',schema)
        self.assertIn('amount_cents INTEGER',schema)

if __name__=='__main__': unittest.main()
