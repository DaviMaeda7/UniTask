import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'app' / '__init__.py').read_text(encoding='utf-8')

class AuthStaticTests(unittest.TestCase):
    def test_python_syntax(self):
        ast.parse(SOURCE)
    def test_passwords_hashed(self):
        self.assertIn('generate_password_hash(password)', SOURCE)
        self.assertIn('check_password_hash(', SOURCE)
    def test_csrf_and_session(self):
        self.assertIn('secrets.compare_digest', SOURCE)
        self.assertIn("session['user_id']", SOURCE)
        self.assertIn("@app.post('/logout')", SOURCE)
    def test_profile_is_protected_and_scoped(self):
        self.assertIn('@login_required\n    def profile()', SOURCE)
        self.assertIn("WHERE user_id=%s", SOURCE)
    def test_previous_schema_retained(self):
        schema = (ROOT / 'schema.sql').read_text(encoding='utf-8')
        self.assertIn('CREATE TABLE IF NOT EXISTS users', schema)
        self.assertIn('CREATE TABLE IF NOT EXISTS student_profiles', schema)
        self.assertIn('CREATE TABLE IF NOT EXISTS company_profiles', schema)

if __name__ == '__main__':
    unittest.main()
